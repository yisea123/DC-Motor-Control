#ifndef __I_PID_H
#define __I_PID_H

void Motor_ctl_Current(void);
#endif
