
/****************************************

bug:   15000һ����





***************************************/








#include "timer.h"
#include "v_pid.h"
#include "motor.h"
#include "p_pid.h"
#include <math.h>
#define VMAX  33   //��ռ�ձȵ��ٶ�
extern int MODE; 

#define kp  1  
#define ki  0
#define kd  0  
struct
{
     float current_error;                  
     float last_error;                     
     float prev_error;                     
}PID_P;                                 
 int PID_P_add=0;
 int Max_V=VMAX;
  int PID_P_add_set;
extern int new_flag;
extern volatile int set_velocity;
extern volatile int user_set_velocity;
extern long Real_Position;
extern volatile long user_Set_Position;
void  Motor_ctl_Position()
{
  
    float P,I,D;
 //  int p_pwm3;
//	  int PID_P_add_set;
    PID_P.prev_error=PID_P.last_error;         
    PID_P.last_error=PID_P.current_error;  
	  PID_P.current_error=user_Set_Position- Real_Position ;  
    P=kp*(PID_P.current_error-PID_P.last_error);
    I=ki*PID_P.current_error;     
    D=kd*(PID_P.current_error-(2*PID_P.last_error)+PID_P.prev_error);
    PID_P_add=PID_P_add+(int)(P+I+D);   
	
    PID_P_add_set=PID_P_add;//Ϊ�˲�����PID������

	if(MODE==3||MODE==5)
	{
		 if(PID_P_add_set>user_set_velocity&&user_set_velocity>0)
        PID_P_add_set=user_set_velocity;                              
		 else if(PID_P_add_set<-user_set_velocity&&user_set_velocity>0)
        PID_P_add_set=-user_set_velocity;  
		 else if(PID_P_add_set<user_set_velocity&&user_set_velocity<0)
        PID_P_add_set=user_set_velocity;                              
		 else if(PID_P_add_set>-user_set_velocity&&user_set_velocity<0)
        PID_P_add_set=-user_set_velocity;  
		 else ;                            //������λ�û��������ٶȻ����ٶ�
		 
     user_set_velocity=PID_P_add_set;	 
		 set_velocity=user_set_velocity;
		 Motor_ctl_Velocity();
	}
	 if(MODE==0)
	{
	 if(PID_P_add_set>0)
    {
      if(PID_P_add_set>3500)
        PID_P_add_set=3500;                              
			Motor_pwm1_set(PID_P_add_set);
			Motor_pwm2_set(0);
    }
      
   if(PID_P_add_set<0)                                 
    {
     
      PID_P_add_set=-PID_P_add_set;                       
      if(PID_P_add_set>3500)
        PID_P_add_set=3500; 
			Motor_pwm1_set(0);
			Motor_pwm2_set(PID_P_add_set);
    }
	}
			 
			 
}





