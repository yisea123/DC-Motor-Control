#include "timer.h"
#include "v_pid.h"
#include "i_pid.h"
#include "motor.h"
extern int MODE; 
#define kp  3 
#define ki  1
#define kd  0   
struct
{
    int current_error;                  
    int last_error;                     
    int prev_error;                     
}PID_M;                                 

extern volatile int Set_Current;
extern volatile int user_Set_Current;

extern int now_velocity;
extern volatile int set_velocity;
extern int Initcurrent;
int PID_v_add=0;
int PID_v_add_set;

void Motor_ctl_Velocity()
{
  
    int P,I,D;
    PID_M.prev_error=PID_M.last_error;         
    PID_M.last_error=PID_M.current_error;     
    PID_M.current_error=set_velocity- now_velocity ;               
    P=(int)(kp*(PID_M.current_error-PID_M.last_error));
    I=(int)(ki*PID_M.current_error);     
    D=(int)(kd*(PID_M.current_error-(2*PID_M.last_error)+PID_M.prev_error));
    PID_v_add=PID_v_add+(P+I+D);   
  
    PID_v_add_set=PID_v_add;
	
	if(MODE==4||MODE==5)
	{
    Set_Current=PID_v_add_set;
		if(Set_Current>Initcurrent+100&&user_Set_Current>Initcurrent)
			Set_Current=Initcurrent+100;//�趨Ϊ�󣬴������
		if(Set_Current<Initcurrent-100&&user_Set_Current>Initcurrent)
			Set_Current=Initcurrent-100;//�趨Ϊ��С����С
		else if(Set_Current<Initcurrent-100&&user_Set_Current<Initcurrent)
        Set_Current=Initcurrent-100; // �趨ΪС��С����С                            
		 else if(Set_Current>Initcurrent+100&&user_Set_Current<Initcurrent)
        Set_Current=Initcurrent+100;  //�趨ΪС���������
		 else ;   
    Motor_ctl_Current();
	}
  else if(MODE==3||MODE==1)
   {
	 if(PID_v_add_set>0)
    {
      if(PID_v_add_set>3500)
        PID_v_add_set=3500;                              
			  Motor_pwm1_set(PID_v_add_set);
			  Motor_pwm2_set(0);
    }
      
   if(PID_v_add_set<0)                                 
    {
     
      PID_v_add_set=-PID_v_add_set;                       
      if(PID_v_add_set>3500)
      PID_v_add_set=3500; 
			Motor_pwm1_set(0);
			Motor_pwm2_set(PID_v_add_set);
    }
	}
   }
