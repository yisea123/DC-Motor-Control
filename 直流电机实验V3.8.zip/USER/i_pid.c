#include "timer.h"
#include "i_pid.h"
#include "motor.h"
extern int MODE; 
#define kp  1.5
#define ki  0.2
#define kd  0   
struct
{
   float current_error;                  
   float last_error;                     
   float prev_error;                     
}PID_I;                                 


int PID_i_add=0;                         

int  PID_i_add_set; 	
extern volatile int user_set_velocity;
extern volatile int now_current;
extern volatile int Set_Current;
extern int Initcurrent;
void Motor_ctl_Current()
{
  
    int P,I,D;
    PID_I.prev_error=PID_I.last_error;         
    PID_I.last_error=PID_I.current_error;     
    PID_I.current_error=Set_Current- now_current ;               
    P=(int)(kp*(PID_I.current_error-PID_I.last_error));
    I=(int)(ki*PID_I.current_error);     
    D=(int)(kd*(PID_I.current_error-(2*PID_I.last_error)+PID_I.prev_error));
    PID_i_add=PID_i_add+(P+I+D);          
	
   if(PID_i_add>=0)
    {
      if(PID_i_add>3500)
        PID_i_add=3500;                              
			  Motor_pwm1_set(PID_i_add);
			  Motor_pwm2_set(0);
    }
      
   if(PID_i_add<0)                                 
    {
     
      PID_i_add_set=-PID_i_add;                       
      if(PID_i_add_set>3500)
				PID_i_add_set=3500; 
			Motor_pwm1_set(0);
			Motor_pwm2_set(PID_i_add_set);
    }
   
   }
